pyinstaller --onefile  GUI.py --add-data "*.png:."             
